We want to design a simple ALU capable of arithmetic operations on 16-bits non-signed values.

The supported operations are:
     - addition
     - subtraction
     - left-shift

The ALU takes in a packet in the following format:
 33 ..                          0 
 --------------------------------
| OP CODE | OPERAND A | OPERAND B|
 --------------------------------
   2bits    16bits       16bits  

OP CODE | OPERATION
-------------------
 2'b01  | ADD
 2'b10  | SUB
 2'b11  | LSHIFT

The output of operation should be a 32-bits result;
 
