#!/bin/sh

TOP_LEVEL=$1

rm -rf xsim*
rm -f *.log *.jou
xvlog *.v
xelab $TOP_LEVEL -timescale 1ns/1ps -debug all
xsim $TOP_LEVEL -g
