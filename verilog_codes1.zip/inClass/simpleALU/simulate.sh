#!/bin/sh

TOP_LEVEL=$1

rm -rf xsim*
rm -f *.log *.jou
xvlog *.v
xelab $TOP_LEVEL -timescale 1ns/1ps
xsim $TOP_LEVEL -R
