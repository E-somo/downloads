#!/bin/sh

rm -rf xsim*
rm -f *.log *.jou *.pb
